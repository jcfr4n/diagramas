<?php unset($_POST) ?>

<?php include("view/encabezado.php") ?>
<!-- Navigation-->
<?php include("view/navegacion.php") ?>
<!-- Page Header-->
<?php include("view/header.php") ?>
<!-- Main Content-->
<?php include("view/main.php") ?>
<!-- Footer-->
<?php include("view/footer.php") ?>