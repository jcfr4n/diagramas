<div class="row">
	<div class="alert alert-success">
		Nota eliminada correctamente. <a href="index.php?controller=note&action=list">Volver al listado</a>
	</div>
</div>